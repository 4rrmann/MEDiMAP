"use client";
import TerminologySearchComponent from "../components/TerminologySearchComponent";

export default function Page() {
  return <TerminologySearchComponent />;
}
